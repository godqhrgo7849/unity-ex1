﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cast : MonoBehaviour
{
	private float speed;
	private Rigidbody rb;

	void Start()
	{
		rb = GetComponent<Rigidbody>();
	}

	void Update()
	{
		speed = Input.GetAxis("Jump");
		if (speed > 0)
		{
			transform.Translate(0, speed, 0);
			transform.rotation = Quaternion.identity;
			rb.AddForce(transform.up * 500);
			rb.AddTorque(Random.Range(0, 500), Random.Range(0, 500), Random.Range(0, 500));
			this.GetComponent<Rigidbody>().velocity = Vector3.up * this.speed;
		}
	}
}